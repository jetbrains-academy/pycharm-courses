# this loop allows us to look at a message, one character at a time
FIRST_MESSAGE = 'It is raining.'
for i in FIRST_MESSAGE:
    print i

# your task: fill in the missing pieces so that the for loop prints the value of SECOND_MESSAGE, one character at a time
SECOND_MESSAGE = 'It is snowing.'
for replace this with a variable in replace with the string to process:
    print replace with a variable
