MESSAGE = 'Hello, World'

# use this pattern:   [substring] in [string_to_search]
print 'Hello' in MESSAGE  # True
print 'HELLO' in MESSAGE  # False (note: case-sensitive)
print 'o' in MESSAGE  # True
print 'Zebra' in MESSAGE  # False


# fill in the code so that it prints whether 'World' is a substring in MESSAGE
print replace with the string to find in replace with the string being searched
