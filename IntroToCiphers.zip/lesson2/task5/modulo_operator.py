print '-- the remainder after dividing 7 by 2 ---'
remainder = 7 % 2
print remainder

print '-- the remainder after dividing 10 by 3 ---'
remainder = 10 replace with the modulo operator 3
print remainder

print '-- the remainder after dividing 3 by 10 ---'
remainder = 3 % replace with the divisor
print remainder





