ENCRYPTED_MESSAGE = 'OVZIM GSV ERTVMVIV XRKSVI'
DECRYPTED_MESSAGE = 'LEARN THE VIGENERE CIPHER'

CIPHER_OPTIONS = ['null','caesar','atbash']

cipher_used_in_this_example = CIPHER_OPTIONS[-1]  # replace with the index of the cipher used in this encryption
