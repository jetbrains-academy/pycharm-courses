ENCRYPTED_MESSAGE = 'MORA EVOCU ECCLESIA TUTIS AUT TIBI NISI OLIM OCIUS NOVEM'
DECRYPTED_MESSAGE = 'MEETATNOON'

CIPHER_OPTIONS = ['null','caesar','atbash']

cipher_used_in_this_example = CIPHER_OPTIONS[-1]  # replace with the index of the cipher used in this encryption
