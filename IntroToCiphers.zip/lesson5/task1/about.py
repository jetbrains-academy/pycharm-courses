ENCRYPTED_MESSAGE = 'XLNV ZG MLLM'

PLAINTEXT_MESSAGE = replace with the decrypted message

print PLAINTEXT_MESSAGE