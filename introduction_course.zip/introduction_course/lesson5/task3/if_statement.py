name = "John"
age = 17

if name == "John" or age == 17:   # check that name is "John" or age is 17. If so print next 2 lines.
    print("name is John")
    print("John is 17 years old")

tasks = ['task1', 'task2']    # create new list

check if 'tasks' is empty
    print("empty")