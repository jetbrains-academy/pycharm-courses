one = 1
two = 2
three = 3

print(one < two < three)  # chained comparison means one < two and two < three at the same time

is_greater = three operator two
print(is_greater)