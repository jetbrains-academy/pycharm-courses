""" documentation string for module my_module
This module contains hello_world function
"""


def hello_world(name):
    print("Hello, World! My name is %s" % name)