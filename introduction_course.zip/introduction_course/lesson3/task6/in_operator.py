ice_cream = "ice cream"
print("cream" in ice_cream)    # print boolean result directly

contains = type here
print(contains)
