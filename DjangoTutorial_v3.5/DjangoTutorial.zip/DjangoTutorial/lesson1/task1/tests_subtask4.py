from test_helper import run_common_tests, failed, passed, get_answer_placeholders, do_not_run_on_check

if __name__ == '__main__':
    do_not_run_on_check()
    run_common_tests()


