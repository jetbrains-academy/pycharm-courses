# This is the comment for the comments.py file
print("Hello!")  # this comment is for the second line

print("# this is not a comment")
# add new comment here
