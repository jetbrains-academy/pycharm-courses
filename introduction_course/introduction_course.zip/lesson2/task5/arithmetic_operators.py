number = 9.0        # float number

result = divide 'number' by two

remainder = calculate the remainder

print("result = " + str(result))
print("remainder = " + str(remainder))
