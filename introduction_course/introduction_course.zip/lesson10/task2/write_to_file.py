zoo = ['lion', "elephant", 'monkey']

if __name__ == "__main__":
    f = open("output.txt", add modifier)

    for i in zoo:
        add the whole zoo to the output.txt

    close the file
