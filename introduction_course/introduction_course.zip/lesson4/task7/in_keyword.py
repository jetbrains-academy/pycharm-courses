grocery_list = ["fish", "tomato", 'apples']   # create new list

print("tomato" in grocery_list)    # check that grocery_list contains "tomato" item

grocery_dict = {"fish": 1, "tomato": 6, 'apples': 3}   # create new dictionary

print(is 'fish' in grocery_dict keys)
