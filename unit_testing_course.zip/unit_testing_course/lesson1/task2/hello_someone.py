def hello_someone(name):
    return "Hello, {}!".format(name)
