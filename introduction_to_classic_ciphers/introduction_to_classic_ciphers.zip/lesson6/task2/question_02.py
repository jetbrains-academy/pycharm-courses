ENCRYPTED_MESSAGE = 'IQ PQTVJ CV PQQP'
DECRYPTED_MESSAGE = 'GO NORTH AT NOON'

CIPHER_OPTIONS = ['null','caesar','atbash']

cipher_used_in_this_example = CIPHER_OPTIONS[-1]  # replace with the index of the cipher used in this encryption
